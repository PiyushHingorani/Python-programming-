/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <conio.h>

int finddistance(int dist)
{
    float km, cm, mm, m;  
    km = dist * 1.609344;
    m  = km * 1000.0;  
    cm = km * 100000.0;  
    mm = km * 1000000.0;  
    printf("Distance in KiloMeter is %f\n", km);
    printf("Distance in Meter is %f\n", m);  
    printf("Distance in Centimeter is %f\n", cm);  
    printf("Distance in Milimeter is %f\n", mm);
}

int main()
{ 
    int dist;
    printf("Enter distance: \n");  
    scanf("%d", &dist);
    finddistance(dist);
    getch();
}