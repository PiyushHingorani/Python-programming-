/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <conio.h>

int findweight(int weightinlbs)
{
    float kg, grams;
    kg = weightinlbs * 0.454;
    grams = kg * 1000;
    printf("Weight in Kilogram is: %f\n", kg);
    printf("Weight in grams is: %f\n", grams); 
}

int main()
{
    int weightinlbs;
    printf("Enter weight in pounds: \n");  
    scanf("%d", &weightinlbs); 
    findweight(weightinlbs);
    getch();
}    