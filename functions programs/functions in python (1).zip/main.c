/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <conio.h>
#include <stdbool.h>
int iseven(int num)
{
    if(num%2 == 0)
    {
        printf("\nIt is an even number");
    }
    else
    {
        return false;
    }
}

int isodd(int num)
{
    if(num%2 != 0)
    {
        printf("\nIt is an odd number");
    }
    else
    {
        return false;
    }
}

int main()
{
    int num;
    printf("Enter a Number: ");
    scanf("%d",&num);
    iseven(num);
    isodd(num);
    getch();
}