/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <conio.h>

int findcount(int amount, int notes)
{
    int count[11] = {2000, 1000, 500, 200, 100, 50, 20, 10, 5, 2, 1};
    for (int i = 0; i <= 11; i++) 
    {
        notes = amount / count[i];
        if (notes)
        {
            amount = amount % count[i]; 
            printf("%d * %d = %d \n", notes, count[i], 
                notes * count[i]);
        }                
    }
}
int main()
{
    int amount, notes;   
    printf("Enter amount: ");
    scanf("%d", &amount);
    printf("\n");
    findcount(amount, notes);
    getch();
}    
