/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <conio.h>

int sumofsquare(int n1, int sum, int num)
{
    while(num>0)
    {
        n1 = num % 10;
        sum = sum + n1 * n1;
        num = num / 10;
    }
    printf("\nthe sum of square of 4 digit number is: %d", sum);
}

int main()
{
    int num, n1, sum = 0;
    printf("enter the 4 digit number: ");
    scanf("%d", &num);
    sumofsquare(n1, sum, num);
    getch();
}