/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <conio.h>
#include<string.h>
using namespace std;

int sum;

void add(int n1, int n2)
{
    sum = n1 + n2;
}

void add(int n1, int n2, int n3)
{
    sum = n1 +n2 + n3;
}

void add(int n1, int n2, int n3, int n4)
{
    sum = n1 + n2 + n3 + n4;
}

void display()
{
    cout<<"\nThe sum is: "<<sum<<"\n";
}

int main()
{
   add(10, 20);
   display();
   add(20, 50, 50);
   display();
   add(10, 20, 30, 40);
   display();
   getch();
}
