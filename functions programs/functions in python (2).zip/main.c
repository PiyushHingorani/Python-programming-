/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdbool.h>
#include <conio.h>

int ispositive(int num)
{
    if(num>0)
    {
        printf("\n%d is a positive number", num);
    }
    else
    {
        return false;
    }
}
int isnegative(int num)
{
    if(num<0)
    {
        printf("\n%d is a negative number", num);
    }
    else
    { 
        printf("\n%d is zero", num);
    }    
}

int main()
{
    int num;
    printf("Enter the number: ");
    scanf("%d", &num);
    ispositive(num);
    isnegative(num);
    getch();
}    