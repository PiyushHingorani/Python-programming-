/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <conio.h>

void isguadrant(int x, int y)
{
    if( x > 0 && y > 0)
	 {
	     printf("\n(%d,%d) lies in first quadrant", x, y);
	 }    
	else if( x < 0 && y > 0)
	 {
	     printf("\n(%d,%d) lies in second quadrant", x, y);
	 }    
	else if( x < 0 && y < 0)
	 {
	     printf("\n(%d,%d) lies in third quadrant", x, y);
	 }    
	else if( x > 0 && y < 0)
	 {
	     printf("\n(%d,%d) lies in fourth quadrant", x, y);
	 }    
	else
	 {
	     printf("\n(%d,%d) lies at origin", x, y);
	 } 
}

int main()
{
    int x,y;
    printf("Enter the coordinates x and y: ");
	scanf("%d %d",&x,&y);
    isguadrant(x, y);
    getch();
}    
