/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <conio.h>

void iseligilbe(int age)
{
    if(age<18)
    {
        printf("\nYou are not eligible to cast your vote");
    }
    else
    {
        printf("\nYou are eligible to cast your vote");
    }
}

int main()
{
    int age;
    printf("Enter the age: ");
    scanf("%d", &age);
    iseligilbe(age);
    getch();
}    