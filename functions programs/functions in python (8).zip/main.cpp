/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <conio.h>
#include<string.h>

using namespace std;

void add(int n1, int n2)
{
    cout<<"\nThe sum is: "<<n1+n2<<"\n";
}

void add(char c1, char c2)
{
    char c[3];
    c[0] = c1;
    c[1] = c2;
    c[2] = '\0';
    cout<<"\nthe sum of characters is: "<<c<<"\n";
}

void add(char c1[], char c2[])
{
  strcat(c1, c2);
  cout<<"\nAddition of two strings: "<<c1<<"\n";
}

int main()
{
   add(10, 20);
   add('p', 'h');
   add("piyush", "hingorani");
   getch();
}

