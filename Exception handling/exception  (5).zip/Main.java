/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
interface Number1
{
    public void getNum1(int n1);
}
interface Number2 extends Number1
{
    public void getNum2( int n2);
}
interface Number3 extends Number2
{
    public void getNum3(int n3);
	public void cal();
}
class Maximum implements  Number3
{
    int num1, num2, num3;
    int max;
    public void getNum1(int n1)
	{
	    num1 = n1;
	}
    public void getNum2(int n2)
	{
	    num2 = n2;
	}
    public void getNum3(int n3)
    {
        num3 = n3;
    }
    public void cal()
    {
        if(num1>num2 && num1>num3)
        {
            max=num1;
        }     
        else if(num2>num1 && num2>num3)
        {
            max=num2;
        }     
        else
        {
            max=num3;
        }
    }
    public void display()
    {
        System.out.println("Maximum is: " +max);
    }
}
class Main
{
    static int num1, num2, num3;
    public static void main(String[] args)
    {
        Scanner scn = new Scanner(System.in);
        System.out.println("\n Enter Number1 =");
        num1 = scn.nextInt();
        System.out.println("\n Enter Number2 =");
        num2 = scn.nextInt();
        System.out.println("\n Enter Number3 =");
        num3 = scn.nextInt();
        Maximum m = new Maximum();
        m.getNum1(num1);
        m.getNum2(num2);
        m.getNum3(num3);
        m.cal();
        m.display();
    }    
}
