/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Vehicle {
    int maxSpeed = 120;
}
 
// sub class Car extending vehicle
class Car extends Vehicle {
    int maxSpeed = 180;
 
    void display()
    {
        // print maxSpeed of base class (vehicle)
        System.out.println("Maximum Speed: "
                           + super.maxSpeed);
    }
}
 
// Driver Program
class Main {
    public static void main(String[] args)
    {
        Car small = new Car();
        small.display();
    }
}