/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Main
{
    public static void main(String args[])
    {
        int num1, num2, sum;
        Scanner scn = new Scanner(System.in);
        System.out.println("enter number1= ");
        num1 = scn.nextInt();
        System.out.println("enter number2= ");
        num2 = scn.nextInt();
        try 
        {
            sum = num1 + num2;
            System.out.println("Sum is: "+sum);
        }
        catch(Exception e)
        {
           char ch;
           System.out.println("enter character= ");
           ch = scn.next().charAt(0);
           System.out.println("Invalid sum");
        }
        finally
        {
            System.out.println("This program ends...");
        }
    }
}