/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
interface Principal
{
    public void getPrin(int pr);
}
interface RateofInterest extends Principal
{
    public void getROI(double r);
}
interface NumberofYears extends RateofInterest
{
    public void getNOY(int ny);
}
class SimpleInterest implements NumberofYears
{
    int prin, noy;
    double roi;
    double si;
    public void getPrin(int pr)
	{
	    prin = pr;
	}
    public void getROI(double r)
	{
	    roi = r;
	}
    public void getNOY(int ny)
	{
	    noy = ny;
	}
    public void cal()
    {
        si = (prin + roi + noy)/100;   
    }    
    public void display()
    {
        System.out.println("Simple Interest is: " +si);
    }
}
class Main
{
    static int prin, noy;
    static double roi;
    public static void main(String[] args)
    {
        Scanner scn = new Scanner(System.in);
        System.out.println("\n Enter principal amount =");
        prin = scn.nextInt();
        System.out.println("\n Enter rate of interest =");
        roi = scn.nextDouble();
        System.out.println("\n Enter Number of years =");
        noy = scn.nextInt();
        SimpleInterest sit = new SimpleInterest();
        sit.getPrin(prin);
        sit.getROI(roi);
        sit.getNOY(noy);
        sit.cal();
        sit.display();
    }    
}