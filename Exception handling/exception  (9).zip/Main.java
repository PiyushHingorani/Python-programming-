/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
interface Length
{
    public void getLen(int l);
}
interface Breadth extends Length
{
    public void getBth(int b);
}
class Rectangle implements Breadth
{
    int len, bdth;
    int area, peri;
    public void getLen(int l)
	{
	    len = l;
	}
	public void getBth(int b)
	{
	    bdth = b;
	}
    public void cal()
    {
        area = len * bdth;   
        peri = 2 * (len + bdth);
    }    
    public void display()
    {
        System.out.println("Area of rectangle is: " +area);
        System.out.println("Perimeter of rectangle is: " +peri);
    }
}
class Main
{
    static int len, bdth;
    public static void main(String[] args)
    {
        Scanner scn = new Scanner(System.in);
        System.out.println("\n Enter Length =");
        len = scn.nextInt();
        System.out.println("\n Enter Breadth =");
        bdth = scn.nextInt();
        Rectangle rt = new Rectangle();
        rt.getLen(len);
        rt.getBth(bdth);
        rt.cal();
        rt.display();
    }    
}
