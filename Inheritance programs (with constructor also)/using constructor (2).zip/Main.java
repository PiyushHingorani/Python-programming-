/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class EmployeeDetails
{
    String name;
    int empid;
    void readData(String nm, int eid)
    {
        name = nm;
        empid = eid;
    }
}
abstract class BasicSalary extends EmployeeDetails
{
    int bs;
    abstract void readsalary(int b);
}
interface Overtime 
{
    public void readhours(int h);
    public void cal_overtime();
}
class NetSalary extends BasicSalary implements Overtime
{
    double overtime;
    int hrs;
    double da, hra, ta, cla, netsal;
    public void readsalary(int b)
    {
        bs = b;
    }
    public void readhours(int h)
    {
        hrs = h;
    }
    public void cal_overtime()
    {
        overtime = hrs * 1.20 * bs;
    }
    public void cal_display()
    {
                da = 1.54 * bs;
                hra = 0.20 * bs;
                cla = 0.05 * bs;
                ta = 2.04 * bs;
                netsal = bs + da + hra + cla + ta + overtime; 
                System.out.println("\nEmployee name: "+name);
                System.out.println("\nEmployee ID: "+empid);
                System.out.println("\nBasic Salary: "+bs);
                System.out.println("\nOvertime: "+overtime);
                System.out.println("\nDA: "+da);
                System.out.println("\nHRA: "+hra);
                System.out.println("\nCLA: "+cla);
                System.out.println("\nTA: "+ta);
                System.out.println("\nNet Salary is: "+netsal);
    }
}
class Main
{
    static String name;
    static int bs, empid, hrs;
    public static void main(String args[])
    {
        Scanner scn = new Scanner(System.in);
        System.out.println("\n Enter Employee Name =");
        String name = scn.nextLine();
        System.out.println("\n Enter Employee ID =");
        empid = scn.nextInt();
        System.out.println("\n Enter Basic Salary =");
        bs = scn.nextInt();
        System.out.println("\n Enter Number of hours worked =");
        hrs = scn.nextInt();
        NetSalary ns = new NetSalary();
        ns.readsalary(bs);
        ns.readhours(hrs);
        ns.cal_overtime();
        ns.cal_display();
    }
}