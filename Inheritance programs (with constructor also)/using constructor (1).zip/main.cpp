/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <conio.h>
using namespace std;

class Area
{
    protected:
               float area;
    public:
            void display()
            {
                cout<<"\nArea is: "<<area<<endl;
            }
};
class Circle: public Area
{
    private:
            int rad;
            float PI = 3.14;
    public:
            void readcircle()
            {
                cout<<"\nEnter the radius of circle: "<<endl;
                cin>>rad;
                PI = 3.14;
            }
            void cal1()
            {
                area = 3.14 * rad * rad;
            }
};
class Triangle: public Area
{
    private:
            int b, h;
    public:
            void readtriangle()
            {
                cout<<"\nEnter the base of triangle: "<<endl;
                cin>>b;
                cout<<"\nEnter the height of triangle: "<<endl;
                cin>>h;
            }
            void cal2()
            {
                area = 0.5 * b * h;
            }
};
class Rectangle: public Area
{
    private:
            int len, bdth;
    public:
            void readrectangle()
            {
                cout<<"\nEnter the length of rectangle: "<<endl;
                cin>>len;
                cout<<"\nEnter the breadth of rectangle: "<<endl;
                cin>>bdth;
            }
            void cal3()
            {
                area = len * bdth;
            }
};
int main()
{
    Circle c;
    Triangle t;
    Rectangle rt;
    c.readcircle();
    c.cal1();
    c.display();
    t.readtriangle();
    t.cal2();
    t.display();
    rt.readrectangle();
    rt.cal3();
    rt.display();
    getch();
}
