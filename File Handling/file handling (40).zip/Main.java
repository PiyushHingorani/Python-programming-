/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Main
{
	public static void main(String args[])
	{
	    int a=20,b=0,c=0;
	
    	try
    	{ 
    	   
    	a = Integer.parseInt(args[0]);
    	c = a /Integer.parseInt(args[1]); 
    	System.out.println("\n C= "+c);
    	}
    	catch(NumberFormatException nfe)
    	{
    		System.out.println("\nCharacter is Enterted Instead of Number");
    	}
    	catch(ArrayIndexOutOfBoundsException aiob)
    	{
    		System.out.println("\nTrying to read from empty array index");
    	}
    	
    	catch(Exception e)
    	{
    		System.out.println("\n i m exception");
    	}
    	finally
    	{
    		System.out.println("I m always there");
    	}
	}

}
