/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class Area
{
    double area;
    void display()
    {
      System.out.println("\nArea is: "+area);
    }
}
class Circle extends Area
{
    int rad;
    void readcircle(int r)
    {
        rad = r;
    }
    void cal1()
    {
        area = 3.14 * rad * rad;
    }
}
class Triangle extends Area
{
    int b, h;
    void readtriangle(int ba, int he)
    {
        b = ba;
        h = he;
    }
    void cal2()
    {
        area = 0.5 * b * h;
    }
}
class Rectangle extends Area
{
    int len, bdth;
    void readrectangle(int l, int b)
    {
      len = l;
      bdth = b;
    }
    void cal3()
    {
        area = len * bdth;
    }
}
class Main
{
    static int rad, b, h, len, bdth;
    public static void main(String args[])
    {
        Scanner scn = new Scanner(System.in);
        System.out.println("\n Enter Radius of circle =");
        rad = scn.nextInt();
        System.out.println("\n Enter base of triangle =");
        b = scn.nextInt();
        System.out.println("\n Enter height of triangle =");
        h = scn.nextInt();
        System.out.println("\n Enter length of rectangle =");
        len = scn.nextInt();
        System.out.println("\n Enter breadth of rectangle =");
        bdth = scn.nextInt();
        Circle cr = new Circle();
        cr.readcircle(rad);       
        cr.cal1();
        cr.display();
        Triangle t = new Triangle();
        t.readtriangle(b, h);       
        t.cal2();
        t.display();
        Rectangle rt = new Rectangle();
        rt.readrectangle(len, bdth);       
        rt.cal3();
        rt.display();
    }
}