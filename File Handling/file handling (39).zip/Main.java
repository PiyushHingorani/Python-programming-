/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class Animal
{
   String nm = "Dog";
}
class Pet extends Animal
{
    String nm = "Cat";
	void display()
	{
	    System.out.println("Animal is: "+nm);
	    System.out.println("Animal is: "+super.nm);
	}
}
class Main
{
    public static void main(String[] args)
    {
        Pet pt = new Pet();
        pt.display();
    }    
}
