/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
interface Digits
{
    public void getData(int n);
}
class Reverse implements Digits
{
    int num, rev, n1;
    public void getData(int n)
	{
	    num = n;
	}
    public void cal_display()
	{
	    while(num>0)
        {
                  n1 = num % 10;
                  rev = rev * 10 + n1;
                  num = num / 10;
        }
        System.out.println("the reverse of 4 digit number is: "+rev);
	}
	
}
class Main
{
    static int num;
    public static void main(String[] args)
    {
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter the number =");
        num = scn.nextInt();
        Reverse rs = new Reverse();
        rs.getData(num);
        rs.cal_display();
    }    
}