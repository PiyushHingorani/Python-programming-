/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class Number1
{
    int num1;
    Number1(int n1)
	{
	    num1 = n1;
	}
}
class Number2 extends Number1
{
    int num2;
    Number2(int n1, int n2)
	{
	    super(n1);
	    num2 = n2;
	}
}
class Number3 extends Number2
{
    int num3;
    Number3(int n1, int n2, int n3)
	{
	    super(n1, n2);
	    num3 = n3;
	}
}
class Maximum extends Number3
{
    int max;
    Maximum(int n1, int n2, int n3)
    {
      super(n1, n2, n3);
    }
    void cal()
    {
        if(num1>num2 && num1>num3)
        {
            max=num1;
        }     
        else if(num2>num1 && num2>num3)
        {
            max=num2;
        }     
        else
        {
            max=num3;
        }
    }
    void display()
    {
        System.out.println("Maximum is: " +max);
    }
}
class Main
{
    static int num1, num2, num3;
    public static void main(String[] args)
    {
        Scanner scn = new Scanner(System.in);
        System.out.println("\n Enter Number1 =");
        num1 = scn.nextInt();
        System.out.println("\n Enter Number2 =");
        num2 = scn.nextInt();
        System.out.println("\n Enter Number3 =");
        num3 = scn.nextInt();
        Maximum m = new Maximum(num1, num2, num3);
        m.cal();
        m.display();
    }    
}
