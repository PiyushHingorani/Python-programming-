/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
abstract class AddData
{
    int num1;
    AddData(int n1)
    {
        num1=n1;
    }
    abstract void add();
}
class Addition extends AddData
{
    int num2;
    int sum;
    Addition(int n1, int n2)
	{
	    super(n1);
        num2 = n2;
	}
    void add()
	{
	    sum = num1 + num2;
	}
	void display()
	{
	    System.out.println("Number1:"+num1);
		System.out.println("Number2:"+num2);
		System.out.println("Sum is:"+sum);
	}
}
class Main
{
    static int num1, num2;
    public static void main(String[] args)
    {
        Scanner scn = new Scanner(System.in);
        System.out.println("\n Enter Number1 =");
        num1 = scn.nextInt();
        System.out.println("\n Enter Number2 =");
        num2 = scn.nextInt();
        Addition ad = new Addition(num1, num2);
        ad.add();
        ad.display();
    }    
}