/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
abstract class Principal
{
    int prin;
    abstract void getPrin(int pr);
}
abstract class RateofInterest extends Principal
{
    double roi;
    abstract void getROI(double r);
}
class NumberofYears extends RateofInterest
{
    int noy;
    void getPrin(int pr)
	{
	    prin = pr;
	}
    void getROI(double r)
	{
	    roi = r;
	}
    void getNOY(int ny)
	{
	    noy = ny;
	}
}
class SimpleInterest extends NumberofYears
{
    double si;
    void cal()
    {
        si = (prin + roi + noy)/100;   
    }    
    void display()
    {
        System.out.println("Simple Interest is: " +si);
    }
}
class Main
{
    static int prin, noy;
    static double roi;
    public static void main(String[] args)
    {
        Scanner scn = new Scanner(System.in);
        System.out.println("\n Enter principal amount =");
        prin = scn.nextInt();
        System.out.println("\n Enter rate of interest =");
        roi = scn.nextDouble();
        System.out.println("\n Enter Number of years =");
        noy = scn.nextInt();
        SimpleInterest sit = new SimpleInterest();
        sit.getPrin(prin);
        sit.getROI(roi);
        sit.getNOY(noy);
        sit.cal();
        sit.display();
    }    
}